import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [name, onChangeTextName] = React.useState('NAME:');
  const [age, onChangeTextAge] = React.useState('AGE:');
  const [address, onChangeTextAddress] = React.useState('ADDRESS:');
  const [school, onChangeTextSchool] = React.useState('SCHOOL:');
  const [course, onChangeTextCourse] = React.useState('Course:');
  const [email, onChangeTextEmail] = React.useState('EMAIL:');
  const [value, onChangeText] = React.useState('ABOUT ME:');


  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextName}
          value={name}
          placeholder="Name:"
         
        />
         <TextInput
          style={styles.input}
          onChangeText={onChangeTextAge}
          value={age}
          placeholder="Age:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextAddress}
          value={address}
          placeholder="Address:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextSchool}
          value={school}
          placeholder="School:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextCourse}
          value={course}
          placeholder="Course:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextEmail}
          value={email}
          placeholder="Email:"

        />
       
        <TextInput
          editable
          multiline
          numberOfLines={5}
          maxLength={40}
          onChangeText={text => onChangeText(text)}
          value={value}
          style={styles.container}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  container: {
    borderBottomColor: '#000',
    borderBottomWidth: 1,
    margine:12,
    marginTop:1,
  },
  textInput: {
    padding: 10,
  },
});

export default TextInputExample;
