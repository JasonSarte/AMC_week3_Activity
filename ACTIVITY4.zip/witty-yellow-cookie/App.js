import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [name, onChangeTextName] = React.useState('NAME:');
  const [age, onChangeTextAge] = React.useState('AGE:');
  const [address, onChangeTextAddress] = React.useState('ADDRESS:');
  const [school, onChangeTextSchool] = React.useState('SCHOOL:');
  const [course, onChangeTextCourse] = React.useState('Course:');
  const [email, onChangeTextEmail] = React.useState('EMAIL:');
  const [contactno, onChangeTextContactno] = React.useState('CONTACT NO.:');
  const [value, onChangeText] = React.useState('ABOUT ME:');


  return (
    <SafeAreaProvider>
      <SafeAreaView>
      
      <View style={style.row}>
      <Image source={{uri: 'https://staticg.sportskeeda.com/editor/2024/01/e0b32-17061405508835-1920.jpg'}}
            style={{width:40,height:50,marginTop:5, marginleft: 5}} />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextName}
          value={name}
          placeholder="Name:"
         
        />
         <TextInput
          style={styles.input}
          onChangeText={onChangeTextAge}
          value={age}
          placeholder="Age:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextAddress}
          value={address}
          placeholder="Address:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextSchool}
          value={school}
          placeholder="School:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextCourse}
          value={course}
          placeholder="Course:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextEmail}
          value={email}
          placeholder="Email:"

        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeTextContactno}
          value={contactno}
          placeholder="CONTACT NO.:"

        />
       
        <TextInput
          editable
          multiline
          numberOfLines={5}
          maxLength={40}
          onChangeText={text => onChangeText(text)}
          value={value}
          style={styles.container}
          placeholder="ABOUT ME:"
          
        />
      </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  container: {
    borderBottomColor: '#000',
    borderBottomWidth: 2,
    borderWidth: 2,
    margine:12,
    height: 100,
    marginTop:5,
    padding: 10,
  },
  textInput: {
    padding: 10,
  },
});

export default TextInputExample;
